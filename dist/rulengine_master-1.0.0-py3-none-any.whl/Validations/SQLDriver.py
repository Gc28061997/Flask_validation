import os
import config
import adal
import pandas as pd
import struct
import pymysql
import pyodbc
import warnings
import asyncio
from sqlalchemy import create_engine
warnings.filterwarnings("ignore", category=UserWarning)

# FOR MYSQL DATAFRAME



async def GetSQLDF(table_name, User, Password, Database):
    server = 'db-data-connect.mysql.database.azure.com'
    engine = pymysql.connect(host=server,user=User,password=Password,database=Database)
    columns_query = f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}' ORDER BY ORDINAL_POSITION"
    columns = pd.read_sql_query(columns_query, engine)['COLUMN_NAME']
    # Get the first column and generate the SELECT query with dynamic hash code
    first_column = columns[0]
    columns = pd.Series(columns)
    columns_name = ','.join(columns.astype(str))
    select_query = f"SELECT {first_column}, SHA2(CONCAT_WS(',', {columns_name}), 256) AS hash FROM {table_name}"

    # Execute the SQL query and retrieve the results into a DataFrame
    data = pd.read_sql_query(select_query, engine)
    
    
    return data


# FOR MSSQL DATAFRAME

async def GetMSSQLDF(Server,table_name, User, Password, Database):
    Server='sql-server-validation.database.windows.net'
    conn = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={Server};DATABASE={Database};UID={User};PWD={Password}'

    engine= pyodbc.connect(conn)
    columns_query = f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}' ORDER BY ORDINAL_POSITION"
    columns = pd.read_sql_query(columns_query, engine)['COLUMN_NAME']
    # Get the first column and generate the SELECT query with dynamic hash code
    first_column = columns[0]
    columns = pd.Series(columns)
    columns_name = ','.join(columns.astype(str))
   
# ...
    select_query = f"SELECT {first_column}, CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', CONCAT({columns_name})), 2) AS hash FROM {table_name}"
# ...


    # Execute the SQL query and retrieve the results into a DataFrame
    data = pd.read_sql_query(select_query, engine)

    engine.close()

    # Print the data
    # print("Data: ",data)
    return data



async def ExecuteSQLQuery(table1, table2):
    df_Source = GetSQLDF(table1)
    df_Destination = GetMSSQLDF(table2)
    
    source_row = df_Source.shape[0]
    destination_rows = df_Destination.shape[0]

    if source_row == destination_rows:
        df_source = df_Source[['Id']]
        df_destination = df_Destination[['Id']]

        compare = df_source.compare(df_destination, result_names=("Source", "Destination"))

        get_data = compare.index
        get_data = [i + 1 for i in get_data]

        source_error_df = df_Source[df_Source.Id.isin(get_data)].sort_index()
        source_error_df = source_error_df.loc[:, source_error_df.columns != 'hash']

        destination_error_df = df_Destination[df_Destination.Id.isin(get_data)].sort_index()
        destination_error_df = destination_error_df.loc[:, destination_error_df.columns != 'hash']
    else:
        print("DataFrame Row Count Not Matched")


